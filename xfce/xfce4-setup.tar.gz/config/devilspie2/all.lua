if string.match(get_window_type(), "WINDOW_TYPE_NORMAL") then
  center()
  if (string.find(get_application_name(),"calculator")==nil) then
    maximize();
  end
  focus();
end
