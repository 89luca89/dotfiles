if string.match(get_window_type(), "WINDOW_TYPE_NORMAL") then
  if (string.find(get_application_name(),"mpv")==nil) then
    if (string.find(get_application_name(),"calculator")==nil) then
      center()
      maximize();
    end
  end
  focus();
end
